# Typecho-Theme-MeaWord
一个极简的用于文字摘录的主题

* 演示站：https://word.meayair.com

---

###更新记录

* 2019-03-08: 第一次上传代码，准备填坑
* 2019-03-11: 更新代码，增添API独立页，用于生成类似于一言的接口（测试： https://word.meayair.com/api ）


---
