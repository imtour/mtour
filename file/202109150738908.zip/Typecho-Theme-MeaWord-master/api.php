<?php
/** 
 * api
 *
 * @package custom
 *  
 * @author      大米_Meayair
 * @version     2019-03-08 0.5
 * 
*/ 
header('content-type:application/json;charset=utf8');
echo json_encode(getRand());
?>